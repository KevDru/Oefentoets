<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Comment;

class CommentSeeder extends Seeder
{
    public function run(): void
    {
        $comment1 = new Comment();
        $comment1->content = 'Comment1';
        $comment1->user_id = 11;
        $comment1->post_id = 1;
        $comment1->save();

        $comment2 = new Comment();
        $comment2->content = 'Comment2';
        $comment2->user_id = 11;
        $comment2->post_id = 2;
        $comment2->save();

        $comment3 = new Comment();
        $comment3->content = 'Comment3';
        $comment3->user_id = 11;
        $comment3->post_id = 3;
        $comment3->save();

        $comment4 = new Comment();
        $comment4->content = 'Comment4';
        $comment4->user_id = 11;
        $comment4->post_id = 4;
        $comment4->save();

        $comment5 = new Comment();
        $comment5->content = 'Comment5';
        $comment5->user_id = 11;
        $comment5->post_id = 5;
        $comment5->save();

        $comment6 = new Comment();
        $comment6->content = 'Comment6';
        $comment6->user_id = 11;
        $comment6->post_id = 6;
        $comment6->save();

        $comment7 = new Comment();
        $comment7->content = 'Comment7';
        $comment7->user_id = 11;
        $comment7->post_id = 7;
        $comment7->save();

        $comment8 = new Comment();
        $comment8->content = 'Comment8';
        $comment8->user_id = 11;
        $comment8->post_id = 8;
        $comment8->save();

        $comment9 = new Comment();
        $comment9->content = 'Comment9';
        $comment9->user_id = 11;
        $comment9->post_id = 9;
        $comment9->save();

        $comment10 = new Comment();
        $comment10->content = 'Comment10';
        $comment10->user_id = 11;
        $comment10->post_id = 10;
        $comment10->save();

    }
}
