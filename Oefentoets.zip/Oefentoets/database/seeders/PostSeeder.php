<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Post;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $post = new Post(); // 1

        $post->subject = 'subject1';
        $post->content = 'content1';

        $post->save();

        $post = new Post(); // 2 

        $post->subject = 'subject2';
        $post->content = 'content2';
        $post->user_id = 2;

        $post->save();

        $post = new Post(); // 3
 
        $post->subject = 'subject3';
        $post->content = 'content3';
        $post->user_id = 3;

        $post->save();

        $post = new Post(); // 4

        $post->subject = 'subject4';
        $post->content = 'content4';
        $post->user_id = 4;

        $post->save();

        $post = new Post(); // 5

        $post->subject = 'subject5';
        $post->content = 'content5';
        $post->user_id = 5;

        $post->save();

        $post = new Post(); // 6

        $post->subject = 'subject6';
        $post->content = 'content6';
        $post->user_id = 6;

        $post->save();

        $post = new Post(); // 7
        
        $post->subject = 'subject7';
        $post->content = 'content7';
        $post->user_id = 7;

        $post->save();

        $post = new Post(); // 8

        $post->subject = 'subject8';
        $post->content = 'content8';
        $post->user_id = 8;

        $post->save();

        $post = new Post(); // 9

        $post->subject = 'subject9';
        $post->content = 'content9';
        $post->user_id = 9;

        $post->save();

        $post = new Post(); // 10

        $post->subject ='subject10';
        $post->content = 'content10';
        $post->user_id = 10;

        $post->save();
    }
}