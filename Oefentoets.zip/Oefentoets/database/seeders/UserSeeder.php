<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    /**
     *chatGPT gebruikt
     *prompt: make 11 random names, email adresses and passwords using this format 
        *$user = new User(); // 1
        *$user->name = '';
        *$user->email = '';
        *$user->password = Hash::make("");
        *$user->save();
     
     */

    public function run(): void
    {
        $user = new User(); // 1

        $user->name = 'Eleanor Rigby';
        $user->email = 'eleanor@example.com';
        $user->password = Hash::make("yellowsubmarine");

        $user->save();

        $user = new User(); // 2

        $user->name = 'Max Power';
        $user->email = 'max.power@example.com';
        $user->password = Hash::make("power123");

        $user->save();

        $user = new User(); // 3

        $user->name = 'Lucy Sky';
        $user->email = 'lucy.sky@example.com';
        $user->password = Hash::make("diamonds");

        $user->save();

        $user = new User(); // 4

        $user->name = 'Rocky Raccoon';
        $user->email = 'rocky.raccoon@example.com';
        $user->password = Hash::make("raccoon456");

        $user->save();

        $user = new User(); // 5

        $user->name = 'Benny Blue';
        $user->email = 'benny.blue@example.com';
        $user->password = Hash::make("blue789");

        $user->save();

        $user = new User(); // 6
 
        $user->name = 'Misty Moon';
        $user->email = 'misty.moon@example.com';
        $user->password = Hash::make("moonlight");

        $user->save();

        $user = new User(); // 7

        $user->name = 'Stella Star';
        $user->email = 'stella.star@example.com';
        $user->password = Hash::make("star123");
        
        $user->save();

        $user = new User(); // 8

        $user->name = 'Ruby Red';
        $user->email = 'ruby.red@example.com';
        $user->password = Hash::make("red456");

        $user->save();

        $user = new User(); // 9

        $user->name = 'Oliver Owl';
        $user->email = 'oliver.owl@example.com';
        $user->password = Hash::make("owl789");

        $user->save();

        $user = new User(); // 10

        $user->name = 'Ginger Gold';
        $user->email = 'ginger.gold@example.com';
        $user->password = Hash::make("gold123");

        $user->save();

        $user = new User(); // 11

        $user->name = 'user';
        $user->email = 'user@example.com';
        $user->password = Hash::make("user");

        $user->save();
       
    }
}