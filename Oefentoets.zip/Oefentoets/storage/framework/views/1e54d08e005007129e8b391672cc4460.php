<?php $__env->startSection('content'); ?>

<br>
<a href="<?php echo e(route('forum.create')); ?>" class="fs-6 btn btn-primary">New post</a>
<br>
 
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <br>
    <div class="border border-black p-3">
        <p class="fs-2"><?php echo e($post->subject); ?></p>
        <p class="fs-5"><?php echo e($post->content); ?></p>
        <p class="fs-6">Posted by <?php echo e($post->user->name); ?>.</p>
        <br>
        <?php if($post->user_id == Auth::user()->id): ?>
            <div class="d-flex align-items-start">
                <a href="<?php echo e(route('forum.edit', $post->id)); ?>" class="me-3 btn btn-primary">Edit</a>
                <br>
                <form action="<?php echo e(route('forum.destroy', $post->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-outline-danger">Delete</button>
                </form>
            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <br>
            <div class="border border-primary p-3">
                <p class="fs-6">Commented by <?php echo e($comment->user->name); ?>.</p>
                <p class="fs-6"><?php echo e($comment->content); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Oefentoets\resources\views/forum/index.blade.php ENDPATH**/ ?>